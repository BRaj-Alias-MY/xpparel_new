using System;
using System.Collections.Generic;
namespace cms.Models {

    public class ClusterInput {
        public Guid ClusterId { get; set; }
        public string ClusterCode { get; set; }
    }
}